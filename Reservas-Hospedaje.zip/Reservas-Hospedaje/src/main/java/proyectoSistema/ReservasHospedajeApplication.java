package proyectoSistema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservasHospedajeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservasHospedajeApplication.class, args);
	}

}
