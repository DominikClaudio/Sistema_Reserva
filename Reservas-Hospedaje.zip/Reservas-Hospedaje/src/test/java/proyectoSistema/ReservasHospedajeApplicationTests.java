package proyectoSistema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservasHospedajeApplicationTests {

	@Test
	void contextLoads() {
	}

}
